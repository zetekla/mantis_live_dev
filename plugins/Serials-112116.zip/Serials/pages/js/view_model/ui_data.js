var tpl_data = {
    sales_order: 'Sales Order',
    customer: 'Customer',
    assembly: 'Assembly',
    revision: 'Revision',
	lang_013:"Scan Serial Number Barcode (auto-submit)",
	list_count: 'List Count',
	printbtn: 'Print',
	searchbtn: 'Search',
	resetbtn: 'Reset',
	cofcbtn: 'C of C',
	htmlbtn: 'HTML'
};
localStorage.setItem("tpl_data", JSON.stringify(tpl_data));